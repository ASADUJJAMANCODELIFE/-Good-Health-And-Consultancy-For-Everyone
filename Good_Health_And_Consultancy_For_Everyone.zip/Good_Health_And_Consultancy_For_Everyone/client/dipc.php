<?php
include("conn.php");
error_reporting(0);
$query ="select * from register";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);

echo $result ['username'];
//echo $total:
if ($total !=0)
{
  //echo "table has record";

}
else{
  echo "table has no record";
}
?>
