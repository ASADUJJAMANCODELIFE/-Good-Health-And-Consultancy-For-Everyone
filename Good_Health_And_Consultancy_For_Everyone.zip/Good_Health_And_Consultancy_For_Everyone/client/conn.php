<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "phppractice";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname );

if ($conn)
{
  //echo "con ok";
}
else{

  echo "con fail".mysqli_connect_error();
}
?>