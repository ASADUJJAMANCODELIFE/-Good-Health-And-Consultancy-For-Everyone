<?php
include ("conn.php");

  
?>

<!DOCTYPE html>

<html lang="en">
  
<head>
 
  <title>REGISTRATION FORM</title>
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
<link rel="stylesheet" type="text/css" href="style1.css">
<link rel="stylesheet" type="text/css" href="style2.css">
<link rel="stylesheet" type="text/css" href="style3.css">
</head>
<body style="background:-webkit-linear-gradient(left, #1B837A, #1B837A); background-size: cover;">
  <form action="client.php" method="POST">
    <Table>
      <tr>
        <td>Name:</td>
        <td><input type="text" name="username" required></td>
       </tr>
       <tr>
        <td>Password:</td>
        <td><input type="text" name="password" required></td>
       </tr>
       
        <tr>
          <td>Gender</td>
          <td><input type="radio" name="gender" value="M"required>Male
          <input type="radio" name="gender"  value="F"required>Female</td>
        </tr>
        <tr>
          <td>Email:</td>
          <td><input type="email" name="email" required></td>
        </tr>
        <tr>
          <td>Phone No:</td>
          <td><select name="phoneCode"> 
            <option selected hidden value=""required>Select Code</option>
            <option value="088">088</option>
            <option value="088">087</option>
            <option value="088">086</option>
            <option value="088">085</option>
            
          </select>
        <input type="phone" name="phone" required>
        </td>
        </tr>

        <tr>
          <td>Blood Group:</td>
          <td><select name="gGroup"> 
            <option selected hidden value=""required>Select Group</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            
          </select>
        
          
         </tr>
         <tr>
          <td>Height</td>
          <td><input type="text" name="height" required></td>
         </tr>
         <tr>
          <td>Weight:</td>
          <td><input type="text" name="weight" required></td>
         </tr>
        <tr>
          <td><input type="submit" value="Submit"></td>
        </tr>
       
    
    </Table>
  </form>
  
</body>
</html>

<?php

$username =$_POST['username'];
$password =$_POST['password'];
$gender =$_POST['gender'];
$email =$_POST['email'];
$phoneCode =$_POST['phoneCode'];
$phone =$_POST['phone'];
$gGroup =$_POST['gGroup'];
$height =$_POST['height'];
$weight =$_POST['weight'];

If( !empty ($username)||
  !empty ($password)||
  !empty ($gender)||
  !empty ($email)||
  !empty ($phoneCode)||
  !empty ($phone) || 
  !empty ($phone) || 
  !empty ($phone) || 
  !empty ($weight) )
  {
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "phppractice";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname );

if (mysqli_connect_error()){
  die ('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
}
else{
  $SELECT = "SELECT email From register Where email = ? Limit 1";
  $INSERT = "INSERT Into register (username, password, gender, email, phoneCode,phone, gGroup,
  height,weight) values (?,?,?,?,?,?,?,?,?)";

  //prepare statement
  $stmt = $conn->prepare($SELECT);
  $stmt->bind_param("s",$email);
  $stmt->execute();
  $stmt->bind_result($email);
  $stmt->store_result();
  $rnum = $stmt->num_rows;

  if ($rnum==0){
    $stmt->close();
    $stmt = $conn->prepare($INSERT);
    $stmt->bind_param("ssssiisss" , $username,$password, $gender, $email, $phoneCode,$phone, $gGroup, $height,$weight);
    $stmt->execute();
    echo "New record inserted successfully";


  }
  else{

    echo "someone already regustered";
  }
  $stmt->close();
  $conn->close();
}
  }
  else{
    echo"all field are required";
    die();
  }
?>