<div align="center">
<link rel="stylesheet" href="style1.css">
<h1 style="color:#5B5B5B"><u>ARGENT MEETING </u></h1>
<table width="1045" height="213" border="1">
  <tbody>
    <tr>
      <td width="241" height="35"><center>zoom</center></td>
       <td><center>24/7<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12PM-12AM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12AM-12PM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
    </tr>
    <tr>
      <td height="57"><center>Skype</center></td>
     <td><center>24/7<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12PM-12AM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12AM-12PM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
    </tr>
    <tr>
      <td height="52"><center>Whatsapp</center></td>
     <td><center>24/7<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12PM-12AM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12AM-12PM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
    </tr>
    <tr>
      <td><center>Telephone/Mobile</center></td>
      <td><center>24/7<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12PM-12AM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
      <td><center>12AM-12PM<br><a href="Updates/meeting.php" style="text-decoration:none"><font size="+1"><b>Doctor List </b></font></center></td>
    </tr>
  </tbody>
</table>
</div>
