<!DOCTYPE html>
<html lang="en">
<head>


</head>
<body>

<!-- header section starts  -->

<header>
<section class="user" id="user">
    
        <h3 class="name">INSTANT CALL SERVICES</h3>
        <p class="post"></p>
       
    </div>

    <nav class="navbar">
        <ul>
            <li><a href="#home">home</a></li>
            <li><a href="#about">about</a></li>
            <li><a href="#education">others</a></li>
            <li><a href="#portfolio">others</a></li>
            <li><a href="#contact">contact</a></li>
        </ul>
    </nav>
    
</section >
</header>

<!-- header section ends -->


</body>
</html>