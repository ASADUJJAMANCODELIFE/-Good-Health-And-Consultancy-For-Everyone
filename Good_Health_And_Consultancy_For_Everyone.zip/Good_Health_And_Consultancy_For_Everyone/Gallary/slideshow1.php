<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>gallery</title>
  <link rel="stylesheet" type="text/css" href="s1.css">
</head>
<body style="background:-webkit-linear-gradient(left, #1B837A, #1B837A); background-size: cover;">  


  <!-- Container for the image gallery -->
<div class="container">

<!-- Full-width images with number text -->
<div class="mySlides">
  <div class="numbertext">1 / 6</div>
    <img src="1.jpg" style="width:30%"><p style="color:blue;font-size:25px;"><span style="color:blue;font-size:30px;">Chris Fox.</span> CEO at Mighty Schools.</p>
  <p style="color:Black;font-size:18px;">John Doe saved us from a web disaster. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores natus culpa aperiam ad at illum tenetur animi quam iste repellat quis, laborum qui necessitatibus excepturi adipisci quisquam! Eveniet, architecto excepturi. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit molestiae iusto, perspiciatis eaque dolorum architecto aliquid labore, dolor facilis sit repellat voluptate consequuntur quidem ipsa fuga soluta provident, asperiores veniam!</p>

  <p>John Doe saved us from a web disaster. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores natus culpa aperiam ad at illum tenetur animi quam iste repellat quis, laborum qui necessitatibus excepturi adipisci quisquam! Eveniet, architecto excepturi. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit molestiae iusto, perspiciatis eaque dolorum architecto aliquid labore, dolor facilis sit repellat voluptate consequuntur quidem ipsa fuga soluta provident, asperiores veniam!</p>
  <p>John Doe saved us from a web disaster. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores natus culpa aperiam ad at illum tenetur animi quam iste repellat quis, laborum qui necessitatibus excepturi adipisci quisquam! Eveniet, architecto excepturi. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit molestiae iusto, perspiciatis eaque dolorum architecto aliquid labore, dolor facilis sit repellat voluptate consequuntur quidem ipsa fuga soluta provident, asperiores veniam!</p>
   
</div>
</div>
 
<div class="container">
<div class="mySlides">
  <div class="numbertext" >2 / 6</div>
    <img src="2.jpg" style="width:30%"><p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
  <p>John Doe saved us from a web disaster. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores natus culpa aperiam ad at illum tenetur animi quam iste repellat quis, laborum qui necessitatibus excepturi adipisci quisquam! Eveniet, architecto excepturi. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit molestiae iusto, perspiciatis eaque dolorum architecto aliquid labore, dolor facilis sit repellat voluptate consequuntur quidem ipsa fuga soluta provident, asperiores veniam!</p>

  <p>John Doe saved us from a web disaster. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores natus culpa aperiam ad at illum tenetur animi quam iste repellat quis, laborum qui necessitatibus excepturi adipisci quisquam! Eveniet, architecto excepturi. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit molestiae iusto, perspiciatis eaque dolorum architecto aliquid labore, dolor facilis sit repellat voluptate consequuntur quidem ipsa fuga soluta provident, asperiores veniam!</p>
  <p>John Doe saved us from a web disaster. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores natus culpa aperiam ad at illum tenetur animi quam iste repellat quis, laborum qui necessitatibus excepturi adipisci quisquam! Eveniet, architecto excepturi. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit molestiae iusto, perspiciatis eaque dolorum architecto aliquid labore, dolor facilis sit repellat voluptate consequuntur quidem ipsa fuga soluta provident, asperiores veniam!</p>
</div>
</div>

<div class="container">
<div class="mySlides">
  <div class="numbertext">3 / 6</div>
    <img src="3.jpg" style="width:30%">
</div>
</div>
<div class="mySlides">
  <div class="numbertext">4 / 6</div>
    <img src="4.jpg" style="width:30%">
</div>

<div class="mySlides">
  <div class="numbertext">5 / 6</div>
    <img src="5.jpg" style="width:30%">
</div>

<div class="mySlides">
  <div class="numbertext">6 / 6</div>
    <img src="6.jpg" style="width:30%">
</div>

<!-- Next and previous buttons -->
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

<!-- Image text -->
<div class="caption-container">
  <p id="caption"></p>
</div>

<!-- Thumbnail images -->
<div class="row">
  <div class="column">
    <img class="demo cursor" src="1.jpg" style="width:100%" onclick="currentSlide(1)" alt="Consultant: name id age expre">
  </div>
  <div class="column">
    <img class="demo cursor" src="2.jpg" style="width:100%" onclick="currentSlide(2)" alt="Cinque Terre">
  </div>
  <div class="column">
    <img class="demo cursor" src="3.jpg" style="width:100%" onclick="currentSlide(3)" alt="Mountains and fjords">
  </div>
  <div class="column">
    <img class="demo cursor" src="4.jpg" style="width:100%" onclick="currentSlide(4)" alt="Northern Lights">
  </div>
  <div class="column">
    <img class="demo cursor" src="5.jpg" style="width:100%" onclick="currentSlide(5)" alt="Nature and sunrise">
  </div>
  <div class="column">
    <img class="demo cursor" src="6.jpg" style="width:100%" onclick="currentSlide(6)" alt="Snowy Mountains">
  </div>
</div>
</div>
</div>
<script>let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("demo");
  let captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}</script>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.container {
  border: 2px solid #ccc;
  background-color: #4ebbb5;
  border-radius: 5px;
  padding: 16px;
  margin: 16px 0
}

.container::after {
  content: "";
  clear: both;
  display: table;
}

.container img {
  float: left;
  margin-right: 20px;
  border-radius: 50%;
}

.container span {
  font-size: 20px;
  margin-right: 15px;
}

@media (max-width: 500px) {
  .container {
      text-align: center;
  }
  .container img {
      margin: auto;
      float: none;
      display: block;
  }
}
</style>
</head>
<body>

<h2>Responsive Testimonials</h2>
<p>Resize the browser window to see the effect.</p>

<div class="container">
  <img src="/w3images/bandmember.jpg" alt="Avatar" style="width:90px">
  <p><span>Chris Fox.</span> CEO at Mighty Schools.</p>
  <p>John Doe saved us from a web disaster.</p>
</div>

<div class="container">
  <img src="/w3images/avatar_g2.jpg" alt="Avatar" style="width:90px">
  <p><span>Rebecca Flex.</span> CEO at Company.</p>
  <p>No one is better than John Doe.</p>
</div>




</body>
</html>
</body>
</html>